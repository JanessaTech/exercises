package net.codejava.user;

public enum Provider {
	LOCAL, FACEBOOK
}
