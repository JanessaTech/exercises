package com.pixeltrice.springbootfacebookloginapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFacebookLoginAppApplication {
	
  
	public static void main(String[] args) {
		SpringApplication.run(SpringBootFacebookLoginAppApplication.class, args);
	}
}
