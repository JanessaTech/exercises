package com.pixeltrice.springbootfacebookloginapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFacebookLoginAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
